/*1:*/
#line 17 "abstime.w"

#include <stdio.h> 
#include <time.h> 

main()
{
printf("#define ABSTIME %ld\n",time(NULL));
return 0;
}
/*:1*/
